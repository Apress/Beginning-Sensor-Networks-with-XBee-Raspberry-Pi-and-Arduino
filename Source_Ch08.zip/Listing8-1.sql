CREATE DATABASE testme;
CREATE TABLE testme.table1 (sensor_node char(30), sensor_value int, sensor_event timestamp);
INSERT INTO testme.table1 VALUES ('living room', 23, NULL);
SELECT * FROM testme.table1;
SET @@global.server_id = 111;
