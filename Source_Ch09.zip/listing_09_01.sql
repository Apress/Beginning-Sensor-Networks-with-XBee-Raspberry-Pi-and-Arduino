CREATE DATABASE test_arduino;
USE test_arduino;
CREATE TABLE hello (source char(20), event_date timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP);
CREATE USER 'arduino_user'@'%' IDENTIFIED WITH mysql_native_password BY 'secret';
GRANT ALL ON *.* to 'arduino_user'@'%';
INSERT INTO hello (source) VALUES ('From Laptop');
SELECT * FROM hello;
