#
# Beginning Sensor Networks Second Edition
# RasPi XBee Remote Storage Data Aggregator 
#
# For this script, we read data from an XBee coordinator
# node whenever data is received from an XBee sensor node.
# We also need a connection to a database server for saving
# the results in a table.
#
# The data read is from one sample (temperature from a
# XBee sensor node and the supply voltage at the source) for
# each device on the network by node id.
#
import serial
import time
from digi.xbee.devices import XBeeDevice
from digi.xbee.io import IOLine, IOMode
import mysql.connector

# MySQL constants
USER = 'arduino_user'       # MySQL user id
PASSWD = 'secret'           # MySQL password
HOST_OR_IP = '192.168.42.8' # MySQL server IP address
PORT = 3306                 # MySQL port
# Query string
INSERT_SQL = ("INSERT INTO house.temperature (address, raw_temp, voltage, celsius, fahrenheit) "
              "VALUES('{0}', {1}, {2}, {3}, {4})")

# Serial port on Raspberry Pi
SERIAL_PORT = "/dev/ttyS0"
# BAUD rate for the XBee module connected to the Raspberry Pi
BAUD_RATE = 9600
# Analog pin we want to monitor/request data
ANALOG_LINE = IOLine.DIO3_AD3
# Sampling rate
SAMPLING_RATE = 15 

# Get an instance of the XBee device class 
device = XBeeDevice(SERIAL_PORT, BAUD_RATE)

# Variables for MySQL Connector/Python code
db_conn = None

# Save the sample in the database
def save_sample(conn, query_str):
    results = None
    cur = conn.cursor(
        cursor_class=mysql.connector.cursor.MySQLCursorBufferedRaw)
    try:
        res = cur.execute(query_str)
    except mysql.connector.Error as e:
        cur.close()
        raise Exception("Query failed. " + e.__str__())
    try:
        results = cur.fetchall()
    except mysql.connector.errors.InterfaceError as e:
        if e.msg.lower() == "no result set to fetch from.":
            pass # This error means there were no results.
        else:    # otherwise, re-raise error
            raise e
    conn.commit()
    cur.close()
    return results

# Method to connect to the network and discover the nodes
def discover_nodes():
    """Get a list of the nodes (node ids) on the network
    Returns:
    """
    # Request the network class and search the network for the remote node
    xbee_network = device.get_network()
    xbee_network.start_discovery_process()
    print("Discovering network", end='')
    while xbee_network.is_discovery_running():
        print(".", end='')
        time.sleep(0.5)
    print("done.")
    devices = xbee_network.get_devices();
    node_ids= []
    for dev in devices:
        print("Found {0} at {1}.".format(dev.get_node_id(), dev.get_64bit_addr()))
        node_ids.append(dev.get_node_id())
    if not node_ids:
        print("WARNING: No nodes found.")
    return node_ids

# Method to connect to the network and get the remote node by id
def get_remote_device(remote_id):
    """Get the remote node from the network
    Returns:
    """
    # Request the network class and search the network for the remote node
    xbee_network = device.get_network()
    remote_device = xbee_network.discover_device(remote_id)
    if remote_device is None:
        print("ERROR: Remote node id {0} not found.".format(remote_id))
        exit(1)
    remote_device.set_dest_address(device.get_64bit_addr())
    remote_device.set_io_configuration(ANALOG_LINE, IOMode.ADC)
    remote_device.set_io_sampling_rate(SAMPLING_RATE)

# Method to get the data when available from the remote node
def io_sample_callback(sample, remote, time):
    address = str(remote.get_64bit_addr())
    # Get the raw temperature value
    raw_temp = sample.get_analog_value(ANALOG_LINE)
    # Calculate supply voltage
    volts = (sample.power_supply_value * (1200.0 / 1024.0)) / 1000.0
    # Save results in the table
    short_addr = address[-4:]
    print("Reading from {0}: {1}, {2}.".format(short_addr, raw_temp, volts))
    # Get the temperature in Celsius
    temp_c = (sample.get_analog_value(ANALOG_LINE) / 1023.0 * 1.25 - 0.5) * 100.0
    # Calculate temperature in Fahrenheit
    temp_f = ((temp_c * 9.0) / 5.0) + 32.0
    print("\tTemperature is {0:.2f}C. {1:.2f}F".format(temp_c, temp_f))
    query = (INSERT_SQL.format(short_addr, raw_temp, volts, temp_c, temp_f))
    save_sample(db_conn, query)
    
# Connect to database server
try:
    parameters = {
        'user': USER,
        'host': HOST_OR_IP,
        'port': PORT,
        'passwd': PASSWD,
        }
    print("Connecting to MySQL...", end='')
    db_conn = mysql.connector.connect(**parameters)
    print("done.")
except mysql.connector.Error as e:
    raise Exception("ERROR: Cannot connect to MySQL Server!")
    exit(1)

try:
    # Read and save temperature data
    print("Welcome to example of storing data from a set of remote TMP36 sensors in MySQL!")
    
    device.open()  # Open the device class
    # Get the nodes on the network
    remote_node_ids = discover_nodes()
    # Setup the remote device
    for remote_id in remote_node_ids:
        get_remote_device(remote_id)
    # Register a listener to handle the samples received by the local device         
    device.add_io_sample_received_callback(io_sample_callback)
    while True:
        pass
except KeyboardInterrupt:
    if device is not None and device.is_open():
        device.close()

# Disconnect from the server
try:
    db_conn.disconnect()
except:
    pass
