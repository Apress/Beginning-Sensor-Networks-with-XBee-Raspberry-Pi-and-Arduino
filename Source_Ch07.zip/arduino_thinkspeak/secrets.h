#define SECRET_SSID "YOUR_SSID"                 // SSID
#define SECRET_PASS "SSID_PASS"                 // WiFi Password
#define SECRET_CH_ID 0000000000                 // Channel number
#define SECRET_WRITE_APIKEY "ABCDEFGHIJKLMNOP"  // Write API Key
