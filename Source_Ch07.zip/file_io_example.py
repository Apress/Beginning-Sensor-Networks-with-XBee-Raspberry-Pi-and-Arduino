#
# Beginning Sensor Networks - Second Edition
#
# Writing data to a file example.
#
# Dr. Charles Bell 2020
#
import datetime

with open("/home/pi/sample_data.txt", "a+") as my_file:
    my_file.write("{0} {1}\n".format(datetime.datetime.now(), 101))

